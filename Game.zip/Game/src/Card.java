public interface Card {
int CARDNUM=13;
int SYMNUM=4;


public abstract String getCard();
public void gameStart(double balance);



}
